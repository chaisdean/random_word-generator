from __future__ import unicode_literals
from django.shortcuts import render, redirect
from django.utils.crypto import get_random_string
import random



def index(request):
    try:
        request.session['load']
    except KeyError:
        request.session['load'] = 0

    return render(request, 'generator/index.html')
# Create your views here.

def random(request):
    #unique_id = get_random_string(length=14)
    print request.POST
    unique_id = get_random_string(length=14)
    request.session['something'] = unique_id
    #request.session['load'] += 1
    #del request.session['load']
    request.session['load'] += 1
    #del request.session['load']
    #request.session['word'] = random_word(10)
    #print unique_id
    return redirect('/')

def reset(request):
    del request.session['load']
    del request.session['something']
    return redirect('/')
